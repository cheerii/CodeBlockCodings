#include <stdio.h>
#include <stdlib.h>

/** \brief
 *
 * \
 * \ WORK with WHILE LOOP
 * \
 *
 */


int main()
{
    printf("Hello world!\n");

    int i = 1;

    while(i != 5){

        printf("%d ich bin ein text\n", i);
        i++;

    }

    return 0;
}
