#include <stdio.h>
#include <stdlib.h>

/** \brief
 *
 * \
 * \
 * \ ARRAY SORT
 * \
 * \
 * \
 *
 */


int main()
{
    printf("Arrays!\n");





    return 0;
}
