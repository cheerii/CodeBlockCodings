#include<stdio.h>
#include<stdlib.h>

struct node
{
        int data;
        struct node *next;
};

int main()
{
        node *start,*temp;
        start = (node *)malloc(sizeof(node));
        temp = start;
        temp -> next = NULL;
        while(1)
        {
                int query;
                printf("1.Insert\n");
                printf("2.Print\n");
                printf("Enter your choice:\n");
                scanf("%d",&query);
                if(query==1)
                {
                        int data;
                        printf("Enter the element to be inserted.\n");
                        scanf("%d",&data);
                        while(start->next!=NULL)
                        {
                                start = start -> next;
                        }
                        start->next = (node *)malloc(sizeof(node));
                        start = start->next;
                        start->data = data;
                        start->next = NULL;
                }
                else if(query ==2)
                {
                        printf("The list is as below:\n");
                        while(start->next!=NULL)
                        {
                                printf("%d \t",start->next->data);
                                start=start->next;

                        }
                }
                else
                break;
        }

        return 0;
}
