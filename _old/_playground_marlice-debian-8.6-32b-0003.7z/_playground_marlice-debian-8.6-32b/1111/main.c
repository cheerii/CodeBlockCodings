#include <stdio.h>
#include <stdlib.h>

int main()
{

    int x, y, rr, i, count = 0;
    printf("Enter first number: ");
    scanf("%d", &x);

    printf("Enter second number: ");
    scanf("%d", &y);

    for(i = 0; i < 5; i++){

        i++;
        count = count + i;
    }

    rr = x + y;
    printf("Sum ist: %d\n", rr);


    return 0;
}
